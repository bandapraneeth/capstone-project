// Where Is My Bus — backend (Express + WebSocket). Run: npm install && npm start
const express = require('express'), http = require('http'), { WebSocketServer } = require('ws');
const crypto = require('crypto'), fs = require('fs'), path = require('path');
const app = express(), srv = http.createServer(app), wss = new WebSocketServer({ server: srv, path: '/ws' });
app.use(express.json()); app.use(express.static(path.join(__dirname, 'public')));
const DRIVER_CODE = process.env.DRIVER_CODE || 'BUS123';

// ---- persistence: survives server restarts, so trip state / model are never lost (Objective 3)
const FILE = path.join(__dirname, 'data.json');
let DB = { users: {}, sessions: {}, buses: {}, samples: [], model: null, err: { ml: [], base: [] } };
try { DB = Object.assign(DB, JSON.parse(fs.readFileSync(FILE))); } catch {}
const save = () => fs.writeFile(FILE, JSON.stringify(DB), () => {});
setInterval(save, 5000); process.on('SIGINT', () => { fs.writeFileSync(FILE, JSON.stringify(DB)); process.exit(); });

// ---- routes (SAMPLE coordinates around Warangal — replace with your real stops)
const ROUTES = {
  R1: { name: 'Hanamkonda → Warangal Station', stops: [['Hanamkonda Bus Stand', 18.0043, 79.5588], ['Nakkalagutta', 18.0001, 79.576], ['Subedari', 17.9926, 79.588], ['Warangal Station', 17.978, 79.601]] },
  R2: { name: 'Station → Fort Warangal', stops: [['Warangal Station', 17.9784, 79.6006], ['Mulugu Rd', 17.9689, 79.5941], ['Mattewada', 17.956, 79.58], ['Fort Warangal', 17.942, 79.56]] }
};
const Rd = 6371000, rad = x => x * Math.PI / 180;
const hav = (a, b, c, d) => { const p = rad(c - a), q = rad(d - b), x = Math.sin(p / 2) ** 2 + Math.cos(rad(a)) * Math.cos(rad(c)) * Math.sin(q / 2) ** 2; return 2 * Rd * Math.asin(Math.sqrt(x)); };
function snap(r, lat, lng) { // project a GPS point onto the route polyline -> distance along route
  let best = { off: 1e12, d: 0 }; const k = Math.cos(rad(lat));
  for (let i = 0; i < r.pts.length - 1; i++) {
    const a = r.pts[i], b = r.pts[i + 1], bx = (b[1] - a[1]) * k, by = b[0] - a[0], px = (lng - a[1]) * k, py = lat - a[0];
    const t = Math.max(0, Math.min(1, (px * bx + py * by) / (bx * bx + by * by || 1e-12)));
    const off = hav(lat, lng, a[0] + by * t, a[1] + bx * t / k);
    if (off < best.off) best = { off, d: r.cum[i] + t * (r.cum[i + 1] - r.cum[i]) };
  } return best;
}
function at(r, d) {
  d = Math.max(0, Math.min(r.len, d)); let i = 1; while (i < r.cum.length - 1 && r.cum[i] < d) i++;
  const t = (d - r.cum[i - 1]) / ((r.cum[i] - r.cum[i - 1]) || 1), a = r.pts[i - 1], b = r.pts[i];
  return { lat: a[0] + (b[0] - a[0]) * t, lng: a[1] + (b[1] - a[1]) * t };
}
for (const r of Object.values(ROUTES)) {
  r.pts = r.stops.map(s => [s[1], s[2]]); r.cum = [0];
  for (let i = 1; i < r.pts.length; i++) r.cum[i] = r.cum[i - 1] + hav(...r.pts[i - 1], ...r.pts[i]);
  r.len = r.cum[r.cum.length - 1]; r.stopD = r.stops.map(s => snap(r, s[1], s[2]).d);
}

// ---- auth: separate roles (user / driver)
const hash = (p, s) => crypto.scryptSync(p, s, 32).toString('hex');
const bad = (res, m, c = 400) => res.status(c).json({ error: m });
const issue = (name, role) => { const t = crypto.randomBytes(24).toString('hex'); DB.sessions[t] = { name, role }; save(); return { token: t, role, name }; };
app.post('/api/register', (req, res) => {
  const { name, pass, role, code } = req.body || {};
  if (!name || !pass || pass.length < 4 || !['user', 'driver'].includes(role)) return bad(res, 'Name, password (4+ chars) and role required');
  if (role === 'driver' && code !== DRIVER_CODE) return bad(res, 'Invalid driver access code', 403);
  const key = role + ':' + name.toLowerCase(); if (DB.users[key]) return bad(res, 'Account already exists', 409);
  const salt = crypto.randomBytes(8).toString('hex'); DB.users[key] = { name, role, salt, h: hash(pass, salt) };
  res.json(issue(name, role));
});
app.post('/api/login', (req, res) => {
  const { name, pass, role } = req.body || {}, u = DB.users[role + ':' + (name || '').toLowerCase()];
  if (!u || u.h !== hash(pass || '', u.salt)) return bad(res, 'Wrong name/password for this role', 401);
  res.json(issue(u.name, u.role));
});

// ---- ML ETA: linear regression trained online from real observed stop arrivals (Objective 4)
function train() {
  const S = DB.samples.slice(-2000); if (S.length < 15) return; let w = DB.model || [0, 0, 0, 0, 0];
  for (let it = 0; it < 400; it++) { const g = [0, 0, 0, 0, 0];
    for (const s of S) { const e = s.x.reduce((a, v, j) => a + v * w[j], 0) - s.y; s.x.forEach((v, j) => g[j] += e * v); }
    w = w.map((v, j) => v - 0.05 * g[j] / S.length); }
  DB.model = w;
}
function etas(r, b) {
  const n = new Date(), h = n.getHours() / 24, we = [0, 6].includes(n.getDay()) ? 1 : 0, sp = b.sp * 3.6;
  return r.stopD.map((sd, i) => {
    if (sd <= b.d) return null; const km = (sd - b.d) / 1000, x = [1, km / 10, h, we, sp / 50];
    return { i, x, base: km / Math.max(sp, 10) * 3600, ml: DB.model ? Math.max(30, DB.model.reduce((s, w, j) => s + w * x[j], 0) * 60) : null };
  });
}
const mae = a => a.length ? +(a.reduce((s, v) => s + v, 0) / a.length).toFixed(2) : null;

// ---- bus state
const M = { msgs: 0, rate: 0, lat: 0, dr: 0, crowd: 0 }; setInterval(() => { M.rate = M.msgs; M.msgs = 0; }, 1000);
const pend = {};
function status(b, now) { return !b.active || now - b.fixTs > 20 * 60000 ? 'offline' : b.src === 'crowd' && now - b.fixTs < 60000 ? 'crowd' : now - b.fixTs < 10000 ? 'live' : 'estimated'; }
function pack(id) {
  const b = DB.buses[id], r = ROUTES[id], now = Date.now(); if (!b) return null;
  return { routeId: id, b: { lat: b.lat, lng: b.lng, speed: b.sp, heading: b.heading, ts: b.ts, fixTs: b.fixTs, status: status(b, now), src: b.src, driver: b.driver }, etas: etas(r, b).map(e => e && { i: e.i, base: e.base, ml: e.ml }) };
}
const bcast = o => { const s = JSON.stringify(o); wss.clients.forEach(c => c.readyState === 1 && c.send(s)); };
function ingest(id, m, who) {
  const r = ROUTES[id]; if (!r || !isFinite(m.lat) || !isFinite(m.lng)) return;
  const b = DB.buses[id] || (DB.buses[id] = { d: 0, sp: 0, ts: 0, fixTs: 0 }), real = m.src !== 'dr';
  m.speed = Math.min(Math.max(+m.speed || 0, 0), 30); // clamp to 0-30 m/s: rejects GPS-noise speeds
  const sn = snap(r, m.lat, m.lng), ts = m.ts || Date.now();
  if (ts < b.ts) return; // late buffered point: already superseded
  const prevD = b.d; b.d = sn.d; b.ts = ts; b.active = true; b.driver = who; b.src = m.src || 'gps';
  b.sp = b.sp ? b.sp * 0.6 + (m.speed || 0) * 0.4 : (m.speed || 0); b.heading = m.heading || 0;
  if (real) b.fixTs = Math.max(b.fixTs, ts);
  if (m.src === 'dr') { const p = at(r, b.d); b.lat = p.lat; b.lng = p.lng; M.dr++; } else { b.lat = m.lat; b.lng = m.lng; }
  // label pending ETA samples when the bus actually reaches a stop -> training data + error stats
  const P = pend[id] || (pend[id] = []);
  r.stopD.forEach((sd, i) => { if (prevD < sd && b.d + 40 >= sd) { const keep = [];
    for (const p of P) { if (p.i !== i) { keep.push(p); continue; } const y = (ts - p.t) / 60000;
      DB.samples.push({ x: p.x, y }); DB.err.base.push(Math.abs(p.base / 60 - y)); if (p.ml != null) DB.err.ml.push(Math.abs(p.ml / 60 - y)); }
    P.splice(0, P.length, ...keep); if (DB.samples.length % 10 === 0) train();
    DB.err.base = DB.err.base.slice(-200); DB.err.ml = DB.err.ml.slice(-200); } });
  if (real && m.src !== 'crowd') etas(r, b).forEach(e => { if (e && (!b['s' + e.i] || ts - b['s' + e.i] > 10000) && P.length < 500) { b['s' + e.i] = ts; P.push({ ...e, t: ts }); } });
  bcast(pack(id));
}
// Dead reckoning on the server: if the driver's phone goes silent, keep moving along the route using last velocity
setInterval(() => { const now = Date.now();
  for (const [id, b] of Object.entries(DB.buses)) { if (!b.active) continue; const r = ROUTES[id];
    if (now - b.fixTs > 20 * 60000) { b.active = false; bcast(pack(id)); continue; }   // driver forgot to end trip -> auto close
    if (now - b.ts > 10000 && b.src !== 'crowd') { b.d = Math.min(r.len, b.d + b.sp * 3); const p = at(r, b.d); b.lat = p.lat; b.lng = p.lng; b.src = 'dr'; M.dr++; }
    bcast(pack(id)); } }, 3000);
setInterval(() => bcast({ type: 'metrics', m: { rate: M.rate, latency: Math.round(M.lat), dr: M.dr, crowd: M.crowd, samples: DB.samples.length, model: !!DB.model, maeMl: mae(DB.err.ml), maeBase: mae(DB.err.base) } }), 5000);

// ---- WebSocket streaming
wss.on('connection', (ws, req) => {
  const s = DB.sessions[new URL(req.url, 'http://x').searchParams.get('token')]; if (!s) return ws.close(4001);
  ws.send(JSON.stringify({ type: 'init', role: s.role, routes: Object.fromEntries(Object.entries(ROUTES).map(([k, r]) => [k, { name: r.name, stops: r.stops, pts: r.pts }])), buses: Object.keys(DB.buses).map(pack) }));
  ws.on('message', raw => { let m; try { m = JSON.parse(raw); } catch { return; } M.msgs++;
    if (s.role === 'driver' && m.type === 'pos') { if (!m.buffered && m.src !== 'dr') M.lat = M.lat * 0.8 + Math.max(0, Date.now() - m.ts) * 0.2; ingest(m.routeId, m, s.name); }
    if (s.role === 'driver' && m.type === 'resume') ws.send(JSON.stringify({ type: 'state', ...pack(m.routeId) }));
    if (s.role === 'user' && m.type === 'crowd') { // anonymized: no identity, coords rounded (~10 m); only used if no official feed
      const b = DB.buses[m.routeId]; M.crowd++;
      if (!b || !b.active || Date.now() - b.fixTs > 60000) ingest(m.routeId, { lat: +m.lat.toFixed(4), lng: +m.lng.toFixed(4), speed: m.speed || 0, ts: Date.now(), src: 'crowd' }, 'crowd'); } });
});
srv.listen(process.env.PORT || 3000, () => console.log('Where Is My Bus on http://localhost:' + (process.env.PORT || 3000)));
